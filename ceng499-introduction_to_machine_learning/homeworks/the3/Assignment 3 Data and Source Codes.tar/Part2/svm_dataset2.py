import pickle
import numpy as np

dataset, labels = pickle.load(open("../data/part2_dataset2.data", "rb"))

