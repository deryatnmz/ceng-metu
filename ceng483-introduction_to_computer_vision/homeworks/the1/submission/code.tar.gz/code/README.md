1-3d_rbg.py file is for part 1 3D Color Histogram (RGB)
2-3d_hsv.py file is for part 2 3D Color Histogram (HSV)
3-rgb_per_channel.py file is for part 3 Per-Channel Color Histogram (RGB)
4-hsv_per_channel.py file is for part 4 Per-Channel Color Histogram (HSV)
5-3d_grid.py file is for 3d histogram's of all three query sets with different grid sizes
6-per_channel_grid.py file is for per-channel histogram's of all three query sets with different grid sizes

All files can be executed without using any arguments. They will print their part's results acoordingly.