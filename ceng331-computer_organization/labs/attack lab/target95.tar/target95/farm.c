/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_132(unsigned x)
{
    return x + 3288256968U;
}

unsigned getval_456()
{
    return 2425379421U;
}

void setval_281(unsigned *p)
{
    *p = 2432553292U;
}

void setval_212(unsigned *p)
{
    *p = 2429389128U;
}

void setval_425(unsigned *p)
{
    *p = 3286206784U;
}

unsigned getval_130()
{
    return 3285027144U;
}

unsigned addval_430(unsigned x)
{
    return x + 3280554213U;
}

unsigned addval_184(unsigned x)
{
    return x + 2446166344U;
}

void setval_110(unsigned *p)
{
    *p = 2425393240U;
}

unsigned getval_225()
{
    return 2448329032U;
}

unsigned addval_352(unsigned x)
{
    return x + 2498660680U;
}

unsigned getval_489()
{
    return 4275390582U;
}

unsigned addval_260(unsigned x)
{
    return x + 3286206824U;
}

unsigned addval_386(unsigned x)
{
    return x + 2431551816U;
}

void setval_493(unsigned *p)
{
    *p = 2425393496U;
}

unsigned getval_331()
{
    return 3285289288U;
}

void setval_335(unsigned *p)
{
    *p = 2056044001U;
}

unsigned getval_341()
{
    return 4275128559U;
}

unsigned addval_102(unsigned x)
{
    return x + 3288191304U;
}

void setval_412(unsigned *p)
{
    *p = 2496497992U;
}

unsigned addval_397(unsigned x)
{
    return x + 2455295778U;
}

unsigned addval_398(unsigned x)
{
    return x + 3277461638U;
}

unsigned getval_150()
{
    return 3268512072U;
}

unsigned getval_112()
{
    return 2462288200U;
}

unsigned addval_255(unsigned x)
{
    return x + 3515697314U;
}

unsigned addval_387(unsigned x)
{
    return x + 2429651272U;
}

unsigned getval_420()
{
    return 2432553288U;
}

void setval_127(unsigned *p)
{
    *p = 2447754072U;
}

unsigned getval_176()
{
    return 3284371784U;
}

unsigned getval_239()
{
    return 3750316244U;
}

unsigned addval_246(unsigned x)
{
    return x + 3286206792U;
}

void setval_365(unsigned *p)
{
    *p = 2431551816U;
}

unsigned addval_410(unsigned x)
{
    return x + 3288191336U;
}

unsigned addval_364(unsigned x)
{
    return x + 2432618824U;
}

unsigned getval_172()
{
    return 2428731720U;
}

void setval_445(unsigned *p)
{
    *p = 3281148491U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
