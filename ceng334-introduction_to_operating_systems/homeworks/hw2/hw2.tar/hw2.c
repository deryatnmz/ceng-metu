#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include "hw2_output.h"

//inputs
int N_size,M_size,K_size;
int ** A_matrix = NULL;
int ** B_matrix = NULL;
int ** C_matrix = NULL;
int ** D_matrix = NULL;

//outputs
int ** J_matrix = NULL;
int ** L_matrix = NULL;
int ** R_matrix = NULL;

//functions
void input_initialize();
void *first_addition(void *thread_id);
void *second_addition(void *thread_id);
void *multiplication(void *thread_id);
void free_all();

//threads
pthread_t *first_addition_threads = NULL;
sem_t * first_addition_mutexes = NULL;
int * first_addition_ids = NULL;

pthread_t *second_addition_threads = NULL;
sem_t ** second_addition_mutexes = NULL;
int * second_addition_ids = NULL;

pthread_t *multiplication_threads = NULL;
int * multiplication_ids = NULL;

int main (){
    hw2_init_output();
    input_initialize();
    
    //start threads
    for (int i = 0; i < N_size; i++) {
        multiplication_ids[i] = i;
        pthread_create(&multiplication_threads[i], NULL, multiplication,  (void *) &multiplication_ids[i]);
    }
    for (int i = 0; i < N_size; i++) {
        first_addition_ids[i] = i;
        pthread_create(&first_addition_threads[i], NULL, first_addition,  (void *) &first_addition_ids[i]);
    }

    for (int i = 0; i < M_size; i++) {
        second_addition_ids[i] = i;
        pthread_create(&second_addition_threads[i], NULL, second_addition,  (void *) &second_addition_ids[i]);
    }

    //join threads
    for (int i=0; i<N_size; i++) {
        pthread_join(first_addition_threads[i], NULL);
    }

    for (int i=0; i<M_size; i++) {
        pthread_join(second_addition_threads[i], NULL);
    }

    for (int i=0; i<N_size; i++) {
        pthread_join(multiplication_threads[i], NULL);
    }

    //print final result
        for(int i=0 ; i<N_size ; i++){
            for(int j = 0; j<K_size; j++){
                printf("%d ",R_matrix[i][j]);
            }
        printf("\n");
    }

    free_all();

}

void *first_addition(void *thread_id){
    int *row;
    row = (int *) thread_id;
    for(int i =0;i<M_size;i++){
        J_matrix[*row][i]=A_matrix[*row][i]+B_matrix[*row][i];
        hw2_write_output(0, *row+1, i+1,  J_matrix[*row][i]);
    }
    sem_post(&first_addition_mutexes[*row]);
    return NULL;
}

void *second_addition(void *thread_id){
    int *row;
    row = (int *) thread_id;
    for(int i =0;i<K_size;i++){
        L_matrix[*row][i]=C_matrix[*row][i]+D_matrix[*row][i];
        hw2_write_output(1, *row+1, i+1,   L_matrix[*row][i]);
        for(int j =0;j<N_size;j++){ //send signal N times
            sem_post(&second_addition_mutexes[*row][i]);
        }
    }
   return NULL;
}

void *multiplication(void *thread_id){

    int *row, sum;
    row = (int *) thread_id;
    sem_wait(&first_addition_mutexes[*row]);

    for(int i =0;i<K_size;i++){
        for(int j =0;j<M_size;j++){ //wait for all columns times
          sem_wait(&second_addition_mutexes[j][i]);
        }   
        sum = 0;
        for(int j =0;j<M_size;j++){
            sum += J_matrix[*row][j]*L_matrix[j][i];
        }
        R_matrix[*row][i]=sum;
        hw2_write_output(2, *row+1, i+1, sum);
    }
    return NULL;
}



void input_initialize(){
    scanf("%d %d", &N_size,&M_size);

    //allocate 
    A_matrix = (int**)malloc(N_size * sizeof(int*));
    B_matrix = (int**)malloc(N_size * sizeof(int*));
    J_matrix = (int**)malloc(N_size * sizeof(int*));

    for(int i=0 ; i<N_size ; i++){
        A_matrix[i] = (int*)malloc(M_size * sizeof(int));
        B_matrix[i] = (int*)malloc(M_size * sizeof(int));
        J_matrix[i] = (int*)malloc(M_size * sizeof(int));
    }

    for(int i=0 ; i<N_size ; i++){
        for(int j = 0; j<M_size; j++){
		scanf("%d", &A_matrix[i][j]);
        }
    }

    scanf("%d %d", &N_size,&M_size);
    for(int i=0 ; i<N_size ; i++){
        for(int j = 0; j<M_size; j++){
            scanf("%d", &B_matrix[i][j]);
        }
    }

    scanf("%d %d", &M_size,&K_size);
    
    //allocate 
    C_matrix = (int**)malloc(M_size * sizeof(int*));
    D_matrix = (int**)malloc(M_size * sizeof(int*));
    L_matrix = (int**)malloc(M_size * sizeof(int*));

    for(int i=0 ; i<M_size ; i++){
        C_matrix[i] = (int*)malloc(K_size * sizeof(int));
        D_matrix[i] = (int*)malloc(K_size * sizeof(int));
        L_matrix[i] = (int*)malloc(K_size * sizeof(int));
    }

    for(int i=0 ; i<M_size ; i++){
        for(int j = 0; j<K_size; j++){
           scanf("%d", &C_matrix[i][j]);
        }
    }

    scanf("%d %d", &M_size,&K_size); 

    for(int i=0 ; i<M_size ; i++){
        for(int j = 0; j<K_size; j++){
            scanf("%d", &D_matrix[i][j]);
        }
    }

    //allocate for R
    R_matrix = (int**)malloc(N_size * sizeof(int*));
    for(int i=0 ; i<N_size ; i++){
        R_matrix[i] = (int*)malloc(K_size * sizeof(int));
    }

    //initialize threads
    first_addition_threads =  (pthread_t*)malloc(N_size * sizeof(pthread_t));
    first_addition_mutexes =  (sem_t*)malloc(N_size * sizeof(sem_t));
    first_addition_ids = (int*)malloc(N_size * sizeof(int));

    multiplication_threads = (pthread_t*)malloc(N_size * sizeof(pthread_t));   
    multiplication_ids = (int*)malloc(N_size * sizeof(int));

    for(int i=0 ; i<N_size ; i++){
        sem_init(&first_addition_mutexes[i],0,0);
    }

    second_addition_threads = (pthread_t*)malloc(M_size * sizeof(pthread_t));
    second_addition_mutexes = (sem_t**)malloc(M_size * sizeof(sem_t*));
    second_addition_ids = (int*)malloc(M_size * sizeof(int));
    for(int i=0 ; i<M_size ; i++){
        second_addition_mutexes[i] = (sem_t*)malloc(K_size * sizeof(sem_t));
    }

    for(int i=0 ; i<M_size ; i++){
        for(int j = 0; j<K_size; j++){
           sem_init(&second_addition_mutexes[i][j],0,0);
        }
    }

}

void free_all(){

    for(int i=0 ; i<N_size ; i++){
        int* currentIntPtr = A_matrix[i];
        free(currentIntPtr);
        currentIntPtr = B_matrix[i];
        free(currentIntPtr);
        currentIntPtr = J_matrix[i];
        free(currentIntPtr);
        currentIntPtr = R_matrix[i];
        free(currentIntPtr);
    }

    for(int i=0 ; i<M_size ; i++){
        int* currentIntPtr = C_matrix[i];
        free(currentIntPtr);
        currentIntPtr = D_matrix[i];
        free(currentIntPtr);
        currentIntPtr = L_matrix[i];
        free(currentIntPtr);
        sem_t * currentIntPtr2 = second_addition_mutexes[i];
        free(currentIntPtr2);
    }
    
    free(first_addition_threads);
    free(first_addition_mutexes);
    free(first_addition_ids);
    free(second_addition_threads);
    free(second_addition_ids);
    free(multiplication_threads);
    free(multiplication_ids);
}
