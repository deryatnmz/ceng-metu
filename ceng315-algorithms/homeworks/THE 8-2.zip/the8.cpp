#include "the8.h"

//DO NOT ADD OTHER LIBRARIES

using namespace std;
#define d 26

vector<int> the8(const string& text, const vector<string>& patterns){
  vector<int> shifts;
  long m = patterns[0].size();
  long n = text.size();
  long i, j,k;
  long t = 0;
  long h = 1;
  long q = 61;

  for (i = 0; i < m - 1; i++)
    h = (h * d) % q;

  list<string> myContainer[61];    
  long ss = patterns.size();
  for (k=0;k<ss;k++){
      long pp=0;
       for (i = 0; i < m; i++) {
        pp= (d * pp + patterns[k][i]) % q;
      }
      myContainer[pp].push_back(patterns[k]);    
 }
  
  for (i = 0; i < m; i++) {
    t = (d * t + text[i]) % q;
  }
    
  for (i = 0; i <= n - m; i++) {
        if(!myContainer[t].empty()){
             for (std::list<string>::iterator it=myContainer[t].begin(); it != myContainer[t].end(); ++it){
                for (j = 0; j < m; j++) {
                    if (text[i + j] != (*it)[j])
                      break;
                      }
                  if (j == m){
                      shifts.push_back(i);
                  }
             }
        }
    if (i < n - m) {
      t = (d * (t - text[i] * h) + text[i + m]) % q;
      if (t < 0)
        t = (t + q);
    }
  }
    return shifts;
}
