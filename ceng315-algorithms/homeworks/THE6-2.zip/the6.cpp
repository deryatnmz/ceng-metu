#include <climits>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <queue>
#include <stack>
#include <unordered_map>
#include <utility>
#include <vector>


bool helper(int v, bool visited[], bool *rs, std::vector<int> &path,int N, std::vector<int>* &adj) {
        if(visited[v] == false) {
            visited[v] = true;
            rs[v] = true;

            std::vector<int>::iterator i;
            for(i=adj[v].begin(); i!=adj[v].end(); i++) {
                                    
                if(!visited[*i] && helper(*i, visited, rs, path,N,adj)) {
                    path.push_back(*i);
                    return true;
                }
                else if(rs[*i]) {
                    return true;
                }
            }
        }
        rs[v] = false;
        path.pop_back();
        return false;   
}

bool cyclepath(std::vector<int> &path, int N,std::vector<int>* &adj) {
        bool *visited = new bool[N];
        bool *recStack = new bool[N];
        for(int i=0; i<N; i++) {
            visited[i] = false;
            recStack[i] = false;
        }

        for(int i=0; i<N; i++) {
            path.push_back(i);
            if(helper(i, visited, recStack, path,N,adj)) {
                return true;
            }
            path.clear();
        }
        path.clear();
        return false;
}    


std::pair<bool, std::vector<int>>
RaceResult(int N, std::vector<std::pair<int, int>> updates) { 
    std::vector<int>* adj = new std::vector<int>[N]; 
    for ( std::vector<std::pair<int, int>>::iterator it = updates.begin(); it != updates.end(); it++){
        adj[(*it).first].push_back((*it).second);}
    
    std::vector<int> in_degree(N, 0);
    for (int u = 0; u < N; u++) {
        std::vector<int>::iterator itr;
        for (itr = adj[u].begin();
             itr != adj[u].end(); itr++)
            in_degree[*itr]++;
    }
    
    std::queue<int> q;
    for (int i = 0; i < N; i++)
        if (in_degree[i] == 0)
            q.push(i);
    int cnt = 0;
    std::vector<int> top_order;
    
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        top_order.push_back(u);
        std::vector<int>::iterator itr;
        for (itr = adj[u].begin();
             itr != adj[u].end(); itr++)
            if (--in_degree[*itr] == 0)
                q.push(*itr);
        cnt++;
    }
    
    if (cnt != N) {
       std::cout<<"cy\n";
        std::vector<int> path;
        cyclepath(path,N,adj);
        std::vector<int> top_order2;
        int mm= path.size();
  
        top_order2.push_back(path[0]);
 
        for(int k=mm-1;k>=0;k--)
           top_order2.push_back(path[k]);

        return {false, top_order2};
    }
 


  return {true, top_order};
}

