#include "the1.h"

int max_int =2147483647;

void swapp (int &a,int &b){
    int temp=a;
    a=b;
    b=temp;
}

int sillySort(int* arr, long &comparison, long & swap, int size) {
    int num_of_calls=1;
    if(size ==2){
        comparison++;
        if(arr[0]>arr[1]){
            swapp(arr[0],arr[1]);
            swap++;
        }
    }
    else if (size >=4){
        num_of_calls += sillySort(arr,comparison,swap,size/2);
        num_of_calls +=sillySort(&arr[size/4],comparison,swap,size/2);
        num_of_calls +=sillySort(&arr[size/2],comparison,swap,size/2);
        num_of_calls +=sillySort(arr,comparison,swap,size/2);
        num_of_calls +=sillySort(&arr[size/4],comparison,swap,size/2);
        num_of_calls +=sillySort(arr,comparison,swap,size/2);
        
    }
	return num_of_calls;
}

void merge_sort_helper(int *arr, int start,int size, long &comparison){   
    if(size>=4){
        int i,l,m,n;
        int len = size/4;
        int *q1= new int[len+1],*q2= new int[len+1],*q3= new int[len+1],*q4 = new int[len+1];
        int *h1=new int[2*len+1], *h2=new int[2*len+1];
        for(i=0;i<len;i++){
            q1[i]=arr[start+i];
            q2[i]=arr[start+len+i];
            q3[i]=arr[start+2*len+i];
            q4[i]=arr[start+3*len+i];
        }
        q1[i]=q2[i]=q3[i]=q4[i]=max_int;
        
        m=n=l=0;
        for(;l<2*len;l++){
            if(q1[m]!=max_int && q3[n]!=max_int){
                comparison++;
            }
            if(q1[m]<=q3[n]){
                h1[l]=q1[m];
                m++;
            }
            else{
                h1[l]=q3[n];
                n++;
            }
        }
        
        m=n=l=0;
        for(;l<2*len;l++){
            if(q2[m]!=max_int && q4[n]!=max_int){
                comparison++;
            }
            if(q2[m]<=q4[n]){
                h2[l]=q2[m];
                m++;
            }
            else{
                h2[l]=q4[n];
                n++;
            }
        }
        h1[l]=h2[l]=max_int;
        
        m=n=l=0;
        for(;l<4*len;l++){
            if(h1[m]!=max_int && h2[n]!=max_int){
                comparison++;
            }
            if(h1[m]<=h2[n]){
                arr[start+l]=h1[m];
                m++;
            }
            else{
                arr[start+l]=h2[n];
                n++;
            }
        }
      delete [] q1, delete [] q2,delete [] q3,delete [] q4,delete [] h1,delete [] h2;
    }
}

int merge(int *arr, int start, int size, long &comparison){
    int num_of_calls=1;
    if(size ==2){
        comparison++;
        if(arr[start]>arr[start+1])
            swapp(arr[start],arr[start+1]);
    }
    else if (size >=4){
        int len = size/4;
        num_of_calls +=merge(arr,start,len,comparison);
        num_of_calls +=merge(arr,start+len,len,comparison);
        num_of_calls +=merge(arr,start+2*len,len,comparison);
        num_of_calls +=merge(arr,start+3*len,len,comparison);
        merge_sort_helper(arr,start,size,comparison);
    }
    return num_of_calls;
}


int crossMergeSort(int *arr, long &comparison, int size){
    int num_of_calls=0;
	num_of_calls+=merge(arr,0,size,comparison);
	return num_of_calls;
}

