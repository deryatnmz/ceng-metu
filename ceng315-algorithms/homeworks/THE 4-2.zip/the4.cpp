#include "the4.h"



int recursive_sln(int i, int*& arr, int &number_of_calls){ //direct recursive
    number_of_calls+=1;
    int x,y;
    if(i<0)
        return -1;
    if(i==0)
        return arr[0];
    if (i==1)
        return (arr[1]>arr[0]?arr[1]:arr[0]);
    if (i==2)
        return( std::max(arr[2],std::max(arr[1],arr[0])));
    x = arr[i]+recursive_sln(i-3,arr,number_of_calls);
    y= recursive_sln(i-1,arr,number_of_calls);
    return (std::max(x,y)); 
}



int memoization_sln(int i, int*& arr, int*& mem){ //memoization
    int x,y;
    if(i<0)
        return -1;
    if(i==0){
        mem[i]=arr[0];
        return arr[0];
    }
    if (i==1){
        mem[i]=arr[1]>arr[0]?arr[1]:arr[0];
        return (arr[1]>arr[0]?arr[1]:arr[0]);
    }
    if (i==2){
        mem[i]=std::max(arr[2],std::max(arr[1],arr[0]));
        return( std::max(arr[2],std::max(arr[1],arr[0])));
    }

    x = arr[i]+memoization_sln(i-3,arr,mem);
    y= memoization_sln(i-1,arr,mem);

    mem[i]=std::max(x,y);
    return (std::max(x,y)); 
}



int dp_sln(int size, int*& arr, int*& mem){ //dynamic programming
    if (size == 0)
        return -1;
    else if(size == 1){
        mem[0]=arr[0];
    }
    else if(size == 2){
        mem[0]=arr[0];
        mem[1]=arr[1]>arr[0]?arr[1]:arr[0];
    }
    else{
        mem[0]=arr[0];
        mem[1]=arr[1]>arr[0]?arr[1]:arr[0];
        mem[2]=std::max(arr[2],std::max(arr[1],arr[0]));
        for(int ii=3;ii<size;ii++){
            mem[ii]=(mem[ii-3]+arr[ii]>mem[ii-1])?(mem[ii-3]+arr[ii]):mem[ii-1];
        }
    }
    return mem[size-1];

}

