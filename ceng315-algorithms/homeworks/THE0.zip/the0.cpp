#include "the0.h"

void insertionSort(int* arr, long &comparison, long & swap, int size) 
{
    int key_index=1;
    while (key_index <size){
        int key = arr[key_index];
        int i = key_index-1;
        comparison++;
        while(i>=0 && arr[i]>key){
            
            comparison++;
            swap++;
            arr[i+1]=arr[i];
            i--;
        }
        arr[i+1]=key;
        key_index ++;
    }
    
}