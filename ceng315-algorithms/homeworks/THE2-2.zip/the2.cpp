#include "the2.h"

void swapp (unsigned short &a,unsigned short &b){
    unsigned short temp=a;
    a=b;
    b=temp;
}
int abs(int x){
    if(x<0)
        return -x;
    else
        return x;
}




int partition(unsigned short* arr,long &swap, double & tot_dist, double & max_dist,int size){
    unsigned short x = arr[size-1];
    int ab,i =-1;
    for(int j=0;j<=(size-2);j++){
        if(arr[j]>=x){
            i++;
            swapp(arr[i],arr[j]);
            swap++;
            ab=i-j;
            ab=abs(ab);
            tot_dist+=ab;
            if (ab>max_dist)
                max_dist=ab;
        }
    }
    swapp(arr[i+1],arr[size-1]);
    swap++;
    ab=i+2-size;
    ab=abs(ab);
    tot_dist+=ab;
    if (ab>max_dist)
                max_dist=ab;
    return (i+1); 
}



void quick_sort_classical(unsigned short *arr, long &swap, double & avg_dist, double & max_dist, int size){
    int p;
    if(size>1){
        p =partition(arr, swap, avg_dist, max_dist, size);
        quick_sort_classical(arr, swap, avg_dist, max_dist,p);
        quick_sort_classical(&(arr[p+1]), swap, avg_dist, max_dist,size-p-1);
    }
	
}

int hoare(unsigned short *arr, long &swap, double & avg_dist, double & max_dist, int size){
    unsigned short x = arr[(int)((size-1)/2)];
    int i = -1;
    int j =size;
    while (true){
        do {
          j--;
        }
        while (arr[j]<x);
        do {
          i++;
        }
        while (arr[i]>x);

        if(i<j){
            avg_dist+=j-i;
            swap++;
         swapp(arr[i],arr[j]);
        if((j-i)>max_dist)
            max_dist = j-i;
        }
        else
            return j;
    }

}

void quick_sort_hoare(unsigned short *arr, long &swap, double & avg_dist, double & max_dist, int size){
    int p;
    if(size>1){
        p =hoare(arr, swap, avg_dist, max_dist, size);
        quick_sort_hoare(arr, swap, avg_dist, max_dist,p+1);
        quick_sort_hoare(&(arr[p+1]), swap, avg_dist, max_dist,size-p-1);
    }
	
}

void quickSort(unsigned short* arr, long &swap, double & avg_dist, double & max_dist, bool hoare, int size)
{
    if(hoare==false)
        quick_sort_classical(arr, swap, avg_dist, max_dist,size);
    else
        quick_sort_hoare(arr, swap, avg_dist, max_dist,size);
    if(swap==0)
        avg_dist =0;
    else
        avg_dist=avg_dist/swap;
}






void patition_3way (unsigned short *arr, long &swap, long &comparison, int size, int &l ,int &r){
    int up,m,k,i =0, j=0;
    int p = size-1;
    while (i<p){
        if(arr[i]>arr[size-1]){
            swapp(arr[i],arr[j]);
            swap++;
            i++;
            j++;
            comparison++;
            
        }
        else if (arr[i]==arr[size-1]){
            p--;
            swapp(arr[i],arr[p]); 
            swap++;
            comparison+=2;
        }
        else {
            i++;
            comparison+=2;
        }
    }
    
    if((p-j)<(size-p))
        m = p-j;
    else
        m=size-p;

    k=size-m;
    up=j;

    for (;up<=j+m-1;up++,k++){
        swapp(arr[up],arr[k]);
        swap++;
    }

    l=j;
    r=p-j;

}

void quickSort3_helper(unsigned short *arr, long &swap, long &comparison,int size, int l , int r) {
    if(size>1){
        patition_3way (arr, swap, comparison, size, l ,r);
        quickSort3_helper(arr,swap, comparison,l,l,r);
        quickSort3_helper(&(arr[size-r]),swap, comparison,r,l,r);
    }
	
}
void quickSort3(unsigned short *arr, long &swap, long &comparison, int size) {
	int l,r;
    quickSort3_helper(arr, swap, comparison,size,l ,r);
}