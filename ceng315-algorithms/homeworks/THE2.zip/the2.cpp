#include "the2.h"

//You may write your own helper functions here

void quickSort(unsigned short* arr, long &swap, double & avg_dist, double & max_dist, bool hoare, int size)
{
    //Your code here
	
}

void quickSort3(unsigned short *arr, long &swap, long &comparison, int size) {
	
    //Your code here
	
}