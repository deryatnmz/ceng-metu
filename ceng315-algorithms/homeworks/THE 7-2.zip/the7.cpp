#include "the7.h"

int path1[10000];
int index1=0;
int c1=0;
int path2[10000];
int index2=0;
int c2=0;


void dijkstra(int * G,int n,int startnode, int end, int fi_or_se) {
   int cost[n][n],distance[n],pred[n];
   int visited[n],count,mindistance,nextnode,i,j;
   for(i=0;i<n;i++){
       for(j=0;j<n;j++){
           if(*(G + i*n + j)==0)
               cost[i][j]=9999999;
           else
              cost[i][j]=*(G + i*n + j);
       }
   }
    
   for(i=0;i<n;i++) {
      distance[i]=cost[startnode][i];
      pred[i]=startnode;
      visited[i]=0;
   }
   distance[startnode]=0;
   visited[startnode]=1;
   count=1;
   while(count<n-1) {
      mindistance=9999999;
      for(i=0;i<n;i++)
         if(distance[i]<mindistance&&!visited[i]) {
         mindistance=distance[i];
         nextnode=i;
      }
      visited[nextnode]=1;
       for(i=0;i<n;i++){
           if(!visited[i])
           {if(mindistance+cost[nextnode][i]<distance[i]) {
             distance[i]=mindistance+cost[nextnode][i];
             pred[i]=nextnode;
           }
       }

      }
      count++;
   }
   
    if(fi_or_se ==1){
            i=end;
        c1+=distance[i];
      j=i;
      do {
         j=pred[j];
        path1[index1]=j;
           index1++;
      }while(j!=startnode);
    }
      else{
            i=end;
          c2+=distance[i];
      j=i;
      do {
         j=pred[j];
        path2[index2]=j;
           index2++;
      }while(j!=startnode);
    }

   
}


void FindRoute(int n, std::vector<Road> roads, int s, int d, int x, int y) {
  std::vector<int> path;
  int cost = INT_MAX;
  int* G = new int[n*n];
      for(int k=0;k<n;k++){
            for(int m=0;m<n;m++)
                *(G + k*n + m)= 0;
      }
    
    std::vector<Road>::iterator ptr;
    for (ptr = roads.begin(); ptr < roads.end(); ptr++){
        *(G + ((*ptr).endpoints.first)*n + (*ptr).endpoints.second)= (*ptr).time;
        *(G + ((*ptr).endpoints.second)*n + (*ptr).endpoints.first)= (*ptr).time;
    }
   path1[index1]=d;
    index1++;
   dijkstra(G,n,y,d,1);
   dijkstra(G,n,x,y,1);
   dijkstra(G,n,s,x,1);
    
   path2[index2]=d;
    index2++;
   dijkstra(G,n,x,d,2);
   dijkstra(G,n,y,x,2);
   dijkstra(G,n,s,y,2);
    
    if(c1<c2){
        for(int dd=index1-1;dd>=0;dd--)
           path.push_back(path1[dd]); 
        cost=c1;
    }
    else{
        for(int dd=index2-1;dd>=0;dd--)
           path.push_back(path2[dd]); 
        cost=c2;
    }


  std::cout << cost << " ";
  PrintRange(path.begin(), path.end());
  std::cout << std::endl;
  delete[] G;
}









