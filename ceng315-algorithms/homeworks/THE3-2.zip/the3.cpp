#include "the3.h"

int count(int n, int stringlen, int l){
    int result = 0;
    if (l==1){
        result = (3*n+26)*stringlen;
    }
    else if(l==2){
        result = (3*n+676)*(stringlen/2);
        if(stringlen%2==1)
            result += (3*n+26);
    }
    else if (l==3){
        result = (3*n+17576)*(stringlen/3);
        if(stringlen%3 ==2)
            result += (3*n+676);
        else if (stringlen%3==1)
            result += (3*n+26);
    }
    else if (l==4){
        result = (3*n+pow(26,4))*(stringlen/4);
        if(stringlen%4==1)
            result += (3*n+26);
        else if(l%4==2)
            result += (3*n+676);
        else if(l%4==3)
            result += (3*n+17576);
    }
    else if (l==6){
        result = (3*n+pow(26,6))*(stringlen/6);
        if(stringlen%6==1)
            result += (3*n+26);
        else if(l%6==2)
            result += (3*n+676);
        else if(l%6==3)
            result += (3*n+17576);
        else if(l%6==4)
            result += (3*n+pow(26,4));        
        else if(l%6==5)
            result += (3*n+pow(26,5));
    }  
    return result;
}



void countSort(std::string arr[], int n, int k){
    std::string *B = new std::string[n];
    int *C = new int[26];
    for (int i = 0; i <26; i++){
        C[i] = 0;
    }
    
    for (int j = 0; j <n; j++){
        C[(int)arr[j][k]-65]++;
    }
    
    for (int f = 1; f <26; f++){
        C[f] += C[f - 1];
    }

    for (int r = n - 1; r >= 0; r--){
        B[C[(int)arr[r][k] -65] - 1] = arr[r];
        C[(int)arr[r][k] -65]--;
    }
    
    for (int l = 0; l < n; l++){
        arr[l] = B[l];
    }

    delete[] B;
    delete[] C;
}


void rvereseArray(std::string arr[], int start, int end)
{
    while (start < end)
    {
        std::string temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
        start++;
        end--;
    }
}    



int radixSort(std::string arr[], bool ascending,int n,int l){
    int lenn = arr[0].size();
    int res=count(n,lenn,l);
    for (int i = lenn-1; i >= 0; i--){ 
        countSort(arr, n,i);
    }
    if(!ascending){
        rvereseArray(arr,0,n-1);
    }
    
    return res;
}