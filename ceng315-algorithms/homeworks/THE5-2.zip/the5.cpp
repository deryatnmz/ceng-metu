#include "the5.h"
// do not add extra libraries here

/*
W: the width of the field
L: the length of the field
partitions: 2D Boolean array for partitions, if a partition of w x l exists then partitions[x][y] is true.
numberOfCalls/numberOfIterations: method specific control parameter
*/

int recursiveMethod(int W, int L, bool** partitions, int* numberOfCalls){
    if (partitions[W][L] == true)
        return 0;
    else {
        int a = W*L;
        int b=9999999,c=99999999,M,N;
        
        for (M=1;M<=(W/2);M++){
            if (b > (recursiveMethod(W-M,L,partitions,numberOfCalls) + recursiveMethod(M,L,partitions,numberOfCalls)))
                 b= recursiveMethod(W-M,L,partitions,numberOfCalls) + recursiveMethod(M,L,partitions,numberOfCalls);
            }
       for(N=1;N<=(L/2);N++) {
           if (c>(recursiveMethod(W,L-N,partitions,numberOfCalls) + recursiveMethod(W,N,partitions,numberOfCalls)))
            c= recursiveMethod(W,L-N,partitions,numberOfCalls) + recursiveMethod(W,N,partitions,numberOfCalls);
       }
        return (std::min (a,std::min(b,c)));
    }
}

int memoizationMethod(int W, int L, bool** partitions, int* numberOfCalls){
	return 0; // this is a dummy return value. YOU SHOULD CHANGE THIS!
}

int bottomUpMethod(int W, int L, bool** partitions, int* numberOfIterations){
	return 0; // this is a dummy return value. YOU SHOULD CHANGE THIS!
}
