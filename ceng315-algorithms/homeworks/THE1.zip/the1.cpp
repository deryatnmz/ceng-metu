#include "the1.h"


//You can add your own helper functions

int sillySort(int* arr, long &comparison, long & swap, int size) 
{

    int num_of_calls=1;
	
	//Your code here
	
	return num_of_calls;
}


int crossMergeSort(int *arr, long &comparison, int size)
{
	
	int num_of_calls=1;
	
	// Your code here
	
	return num_of_calls;
	
}