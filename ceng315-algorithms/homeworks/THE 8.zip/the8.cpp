#include "the8.h"

//DO NOT ADD OTHER LIBRARIES

using namespace std;

vector<int> the8(const string& text, const vector<string>& patterns){

    vector<int> shifts; //DO NOT CHANGE THIS

    /*****************
     *
     * YOUR CODE HERE
     *
     * *************/

    return shifts; //DO NOT CHANGE THIS
}
